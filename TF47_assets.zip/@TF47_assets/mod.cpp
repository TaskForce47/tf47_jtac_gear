﻿name=TF47_assets;
picture="tf47_logo.paa";
action="";
hidePicture=0;
hideName=0;
